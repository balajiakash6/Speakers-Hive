package com.speakershive.controller;

import com.speakershive.entity.User;
import com.speakershive.service.EmailService;
import com.speakershive.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;



import java.util.Optional;
import java.util.Random;

@Controller
public class PasswordController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @GetMapping("/reset-password")
    public String showResetPasswordPage(
        @RequestParam(required = false) String token,
        Model model) {

    model.addAttribute("token", token);
    return "reset-password";
}

    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot-password";
    }


    // Request password reset
    @PostMapping("/reset-password")
    public String resetPasswordRequest(@RequestParam String email, Model model) {
        Optional<User> optionalUser = userService.findByEmail(email);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            String tempPassword = generateTempPassword();

            // create reset token and set temporary password
            String token = userService.createResetToken(user);
            String encodedTempPassword = passwordEncoder.encode(tempPassword);
            user.setPassword(encodedTempPassword);
            userService.save(user);

            // Send email
            emailService.sendEmail(user.getEmail(), "Temporary Password",
                    "Your temporary password is: " + tempPassword + "\nUse it to login and reset your password.");
            model.addAttribute("message", "Temporary password sent to your email.");
        } else {
            model.addAttribute("error", "Email not found.");
        }
        return "reset-password-result";
    }

    // Update password using token
    @PostMapping("/update-password")
    public String updatePassword(@RequestParam String token,
                                 @RequestParam String newPassword,
                                 Model model) {
        String encodedPassword = passwordEncoder.encode(newPassword);
        boolean success = userService.updatePasswordWithToken(token, encodedPassword);

        if (success) {
            model.addAttribute("message", "Password updated successfully.");
        } else {
            model.addAttribute("error", "Invalid or expired token.");
        }
        return "update-password-result";
    }

    private String generateTempPassword() {
        int length = 10;
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$";
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++)
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        return sb.toString();
    }
}
