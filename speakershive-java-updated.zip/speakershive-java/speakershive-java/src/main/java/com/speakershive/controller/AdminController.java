package com.speakershive.controller;

import com.speakershive.entity.User;
import com.speakershive.service.EmailService;
import com.speakershive.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("users", userService.findAllUsers());
        return "admin-dashboard";
    }

    @PostMapping("/create-user")
public String createUser(@RequestParam String email, Model model) {

    if (userService.findByEmail(email).isPresent()) {
        model.addAttribute("message", "User already exists ❌");
        model.addAttribute("users", userService.findAllUsers());
        return "redirect:/admin/dashboard?error=user-exists";
    }

    String tempPassword = UUID.randomUUID().toString().substring(0, 8);

    User user = new User();
    user.setEmail(email);
    user.setPassword(passwordEncoder.encode(tempPassword));
    user.setRole("ROLE_MEMBER");
    user.setActive(true);

    userService.createUser(user);

    try {
        // 🔴 USE ONLY THIS METHOD (the one you ALREADY had earlier)
        emailService.sendTempPasswordEmail(email, tempPassword);
        model.addAttribute("message", "User created & email sent ✅");
    } catch (Exception e) {
        e.printStackTrace();
        model.addAttribute("message", "User created but email failed ❌");
    }

    model.addAttribute("users", userService.findAllUsers());
    return "redirect:/admin/dashboard?success=user-created";
}
}