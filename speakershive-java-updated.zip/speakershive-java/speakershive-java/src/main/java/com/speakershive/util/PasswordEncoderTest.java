package com.speakershive.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoderTest {

    public static void main(String[] args) {

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String rawPassword = "Mi@10312006";
        String encodedPassword = encoder.encode(rawPassword);

        System.out.println("=================================");
        System.out.println("RAW PASSWORD  : " + rawPassword);
        System.out.println("BCrypt HASH   : " + encodedPassword);
        System.out.println("=================================");
    }
}
