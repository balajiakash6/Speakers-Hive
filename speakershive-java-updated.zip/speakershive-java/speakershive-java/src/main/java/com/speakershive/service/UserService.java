package com.speakershive.service;

import com.speakershive.entity.User;
import com.speakershive.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // 🔍 FIND BY EMAIL
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // 📋 ALL USERS
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    // ✅ CHECK EXISTS
    public boolean existsByEmail(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    // 🔐 NORMAL USER CREATION (USED ELSEWHERE)
    public User createUser(User user) {
        // Encode only if NOT already encoded
        if (!user.getPassword().startsWith("$2a$")) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        return userRepository.save(user);
    }

    // 💾 SAVE (ADMIN FLOW USES THIS)
    public User save(User user) {
        return userRepository.save(user);
    }

    // 🔑 RESET TOKEN
    public String createResetToken(User user) {
        String token = UUID.randomUUID().toString();
        user.setResetToken(token);
        user.setResetTokenExpiry(System.currentTimeMillis() + 3600_000); // 1 hour
        userRepository.save(user);
        return token;
    }

    // 🔄 UPDATE PASSWORD USING TOKEN
    public boolean updatePasswordWithToken(String token, String newPassword) {
        Optional<User> optionalUser = userRepository.findByResetToken(token);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

            if (user.getResetTokenExpiry() != null &&
                user.getResetTokenExpiry() > System.currentTimeMillis()) {

                user.setPassword(passwordEncoder.encode(newPassword));
                user.setResetToken(null);
                user.setResetTokenExpiry(null);
                userRepository.save(user);
                return true;
            }
        }
        return false;
    }
}
