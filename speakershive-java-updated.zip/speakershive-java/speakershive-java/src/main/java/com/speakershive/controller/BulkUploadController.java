package com.speakershive.controller;

import com.speakershive.service.ExcelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class BulkUploadController {

    @Autowired
    private ExcelService excelService;

    @PostMapping("/admin/upload-users")
    public String uploadUsers(
            @RequestParam("file") MultipartFile file,
            RedirectAttributes redirectAttributes) {

        try {
            excelService.importUsersFromExcel(file);
            redirectAttributes.addFlashAttribute("success", "Users uploaded successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Upload failed");
        }

        return "redirect:/admin/users";
    }
}
