package com.speakershive.service;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    // ✅ Generic email sender
    public void sendEmail(String to, String subject, String body) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(body, true); // true = HTML content
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // ✅ Send temporary password + reset link
    public void sendTempPasswordEmail(String to, String tempPassword) {
        String subject = "Welcome to Speakers Hive! \n Your Account Has Been Created!";
        String resetLink = "http://localhost:8081/reset-password"; // adjust if your reset page differs
        String body = "<p>Hello,</p>"
                    + "<p>Your account has been created successfully.</p>"
                    + "<p>Temporary password: <b>" + tempPassword + "</b></p>"
                    + "<p>Please reset your password using this link: "
                    + "<a href='" + resetLink + "'>Reset Password</a></p>"
                    + "<p>Thank you!</p>";

        sendEmail(to, subject, body);
    }
}
