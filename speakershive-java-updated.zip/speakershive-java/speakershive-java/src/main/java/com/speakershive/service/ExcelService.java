package com.speakershive.service;

import com.speakershive.entity.User;
import com.speakershive.repository.UserRepository;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Iterator;

@Service
public class ExcelService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ✅ METHOD NAME MATCHES CONTROLLER
    public void importUsersFromExcel(MultipartFile file) {

        try (InputStream is = file.getInputStream()) {

            Workbook workbook = WorkbookFactory.create(is);
            Sheet sheet = workbook.getSheetAt(0);

            Iterator<Row> rows = sheet.iterator();
            rows.next(); // skip header row

            while (rows.hasNext()) {
                Row row = rows.next();

                User user = new User();
                user.setName(row.getCell(0).getStringCellValue());
                user.setEmail(row.getCell(1).getStringCellValue());
                user.setPhone(row.getCell(2).getStringCellValue());

                user.setPassword(passwordEncoder.encode("Temp@123"));
                user.setRole("MEMBER");
                user.setActive(true);

                userRepository.save(user);
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to upload Excel file", e);
        }
    }
}
